import React from 'react';
import '../../App.css';
import HeroSection from '../frontPage_components/HeroSection';

import Footer from '../frontPage_components/Footer';

function Home (){
    return (
        <>
            <HeroSection />
            <Footer />

        </>
    );
}

export default Home;